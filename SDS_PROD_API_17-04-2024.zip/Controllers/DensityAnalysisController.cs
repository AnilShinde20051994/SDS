﻿using Aadyam.SDS.Business.Model.DensityAnalysis;
using Aadyam.SDS.Business.Model.User;
using System.Collections.Generic;
using System.Web.Http;

namespace Aadyam.SDS.API.Controllers
{
    [RoutePrefix("DensityAnalysis")]
    public class DensityAnalysisController : BaseApiController
    {
        [HttpPost]
        [Route("GetPendingOrderWithDensityAnalysis")]
        public List<PendingOrderDensityAnalysis> GetPendingOrderWithDensityAnalysis([FromBody]PostModel postModel)
        {
            return _unitOfWork._DensityAnalysisRepository.GetPendingOrderWithDensityAnalysis(postModel);
        }

        [HttpPost]
        [Route("GetDensityAnalysisSummary")]
        public List<DensityAnalysisSummary> GetDensityAnalysisSummary([FromBody]PostModel postModel)
        {
            return _unitOfWork._DensityAnalysisRepository.GetDensityAnalysisSummary(postModel);
        }

        [HttpPost]
        [Route("GetTripCasesSummary")]
        public List<DensityAnalysisSummary> GetTripCasesSummary([FromBody]PostModel postModel)
        {
            return _unitOfWork._DensityAnalysisRepository.GetTripCasesSummary(postModel);
        }

        [HttpPost]
        [Route("GetTripCasesSummaryforAD")]
        public List<DensityAnalysisSummary> GetTripCasesSummaryforAD([FromBody]PostModel postModel)
        {
            return _unitOfWork._DensityAnalysisRepository.GetTripCasesSummaryforAD(postModel);
        }

        [HttpPost]
        [Route("GetDensityAnalysisConsumerDetails")]
        public List<ConsumerListDensityAnalysis> GetDensityAnalysisConsumerDetails([FromBody]PostModel postModel)
        {
            return _unitOfWork._DensityAnalysisRepository.GetDensityAnalysisConsumerDetails(postModel);
        }

        [HttpPost]
        [Route("GetConsumerDetails")]
        public List<ConsumerListDensityAnalysis> GetConsumerDetails([FromBody]PostModel postModel)
        {
            return _unitOfWork._DensityAnalysisRepository.GetConsumerDetails(postModel);
        }

        [HttpPost]
        [Route("GetPendingBookingForDensity")]
        public List<PendingBookingForDensity> GetPendingBookingForDensity([FromBody]PostModel postModel)
        {
            return _unitOfWork._DensityAnalysisRepository.GetPendingBookingForDensity(postModel);
        }

        [HttpPost]
        [Route("GetDensityAnalysisSummary_RtSeq")]
        public List<DensityAnalysisSummary> GetDensityAnalysisSummary_RtSeq([FromBody]PostModel postModel)
        {
            return _unitOfWork._DensityAnalysisRepository.GetDensityAnalysisSummary_RtSeq(postModel);
        }

        [HttpPost]
        [Route("GetDensityAnalysisConsumerDetails_RtSeq")]
        public List<ConsumerListDensityAnalysis> GetDensityAnalysisConsumerDetails_RtSeq([FromBody]PostModel postModel)
        {
            return _unitOfWork._DensityAnalysisRepository.GetDensityAnalysisConsumerDetails_RtSeq(postModel);
        }

    }
}
