﻿using Aadyam.SDS.API.Controllers;
using Aadyam.SDS.Business.BusinessConstant;
using Quartz;
using System;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class CheckLatestGCInsOut: BaseApiController, IJob
    {      
        public void Execute(IJobExecutionContext context)
        {
            long ResultId = 0;
            try
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "Check Latest GC Ins Out - Scheduler", "CheckLatestGCInsOut", "START", "");
                ResultId = _unitOfWork.geoCoordinateRepository.CheckLatestGCInsOutNew(0);
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "Check Latest GC Ins Out - Scheduler", "CheckLatestGCInsOut - ResultId : " + ResultId, "END", "");
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "Check Latest GC Ins Out - Scheduler", "CheckLatestGCInsOut - ResultId : " + ResultId + " & Exception = " + (ex.Message), BusinessCont.FailStatus, ex.Message);
            }
        }
    }
}