﻿using Aadyam.SDS.API.Controllers;
using Aadyam.SDS.Business.BusinessConstant;
using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class ConsumerVerificationStatus : BaseApiController, IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            int result1 = 0;

            try
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "GetConsumerVerificationScheduler", "Scheduler Execution Start", BusinessCont.SuccessStatus, null);
                result1 = _unitOfWork.geoCoordinateRepository.GetConsumerVerificationScheduler();
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "GetConsumerVerificationScheduler", "Scheduler Execution End", BusinessCont.SuccessStatus, null);

            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, 0, 0, 0, "GetConsumerVerificationScheduler", null, BusinessCont.FailStatus, ex.Message);
            }
        }
    }
}