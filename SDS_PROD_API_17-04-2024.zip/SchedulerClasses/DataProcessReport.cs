﻿using Aadyam.SDS.API.Controllers;
using Aadyam.SDS.Business.BusinessConstant;
using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class DataProcessReport : BaseApiController, IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            bool result = false;
            try
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "DataProcessReport", "Scheduler Execution Start", BusinessCont.SuccessStatus, null);
                result = _unitOfWork._tripRepository.GetDataProcessRpt();
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "DataProcessReport", "Scheduler Execution End", BusinessCont.SuccessStatus, null);

            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, 0, 0, 0, "DataProcessReport", null, BusinessCont.FailStatus, ex.Message);
            }
        }
    }
}