﻿using Aadyam.SDS.Business.BusinessConstant;
using Aadyam.SDS.Business.Model.GeoCoordinates;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Configuration;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class EmailClass
    {
        public bool SendEmails(string ToEmail,string UserName,string Password, string Subject, string message)
        {
            bool bResult = false;
            SmtpClient mailClient = null;
            // Create the mail message
            MailMessage mailMessage = null;
            try
            {
                mailClient = new SmtpClient();
                mailMessage = new MailMessage();//(from, to, subject, body);
                //mailMessage.From = new MailAddress(UserName);
                if (!string.IsNullOrWhiteSpace(ToEmail))//Recipient Email
                {
                    string ToEmailId = ToEmail.Trim();
                    if (ToEmailId.Contains(";"))
                    {
                        string[] emails = ToEmailId.Trim().Split(';');
                        foreach (string email in emails)
                        {
                            mailMessage.To.Add(email.Trim());
                        }
                    }
                    else
                    {
                        mailMessage.To.Add(ToEmailId);
                    }

                    string MappedFilePath = AppDomain.CurrentDomain.BaseDirectory;
                    string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Mailfile\\SendEmail.html");
                    string messageformat = System.IO.File.OpenText(filePath).ReadToEnd().ToString();
                    // Replace Notification Table
                    messageformat = messageformat.Replace("<!--SchedulerTableString-->", message);
                    mailMessage.From = new MailAddress(UserName,"Smart Delivery System");
                    mailClient.Port = 587;
                    mailClient.Host = "smtp.gmail.com"; //for gmail host  
                    mailClient.EnableSsl = true;
                    mailClient.UseDefaultCredentials = false;
                    mailClient.Credentials = new NetworkCredential(UserName, Password);
                    mailClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                    mailMessage.Subject = Subject;
                    mailMessage.IsBodyHtml = true;
                    mailMessage.Body = messageformat;
                    mailClient.Send(mailMessage);

                    bResult = true;
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "EmailClass", "Code= 0, Flag=ALL", BusinessCont.FailStatus, ex.Message);
                throw ex;
            }
            finally
            {
                if (mailClient != null)
                    mailClient.Dispose();

                if (mailMessage != null)
                    mailMessage.Dispose();
            }
            return bResult;
        }

        public bool SendEmails(string ToEmail, string Subject, string message, string[] AttachFilePath)
        {
            BusinessCont.SaveLog(0, 0,0,0,0, "Scheduler Send Emails 1 " + "ToEmail : " + ToEmail + "Subject : " + Subject + "message : " + message + "AttachFilePath :" + AttachFilePath.ToString(), "","","");
            bool bResult = false;
            // To send an Email
            SmtpClient mailClient = null;
            // Create the mail message
            MailMessage mailMessage = null;
            // Attach file
            Attachment attachment1 = null;
            try
            {
                string userName = WebConfigurationManager.AppSettings["PFUserName"];
                string password = WebConfigurationManager.AppSettings["PFPassWord"];
                mailClient = new SmtpClient("smtp.gmail.com");
                // Create the mail message
                mailMessage = new MailMessage();//(from, to, subject, body);

                if (!string.IsNullOrWhiteSpace(ToEmail))//For RO Email
                {
                    try
                    {
                        string ToEmailId = ToEmail.Trim();
                        if (ToEmailId.Contains(";"))
                        {
                            string[] emails = ToEmailId.Trim().Split(';');
                            foreach (string email in emails)
                            {
                                mailMessage.To.Add(email.Trim());
                            }
                        }
                        else
                        {
                            mailMessage.To.Add(ToEmailId.Trim());
                        }
                        //mailMessage.To.Add(ToEmail);
                    }
                    catch (Exception ex)
                    {
                        BusinessCont.SaveLog(0, 100, 0, 0, 0, "EmailClass", "Code= 0, Flag=ALL", BusinessCont.FailStatus, ex.Message);
                        throw ex;
                    }
                }
                if (AttachFilePath != null)
                {
                    foreach (string filePath in AttachFilePath)
                    {
                        if (filePath != null)
                        {
                            attachment1 = new System.Net.Mail.Attachment(filePath); //Attaching File to Mail
                            mailMessage.Attachments.Add(attachment1);
                            attachment1 = null;
                        }
                    }
                }

                string MappedFilePath = AppDomain.CurrentDomain.BaseDirectory;
                string filePath1 = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Mailfile\\SendEmail.html");
                string messageformat = System.IO.File.OpenText(filePath1).ReadToEnd().ToString();
                // Replace Notification Table
                messageformat = messageformat.Replace("<!--SchedulerTableString-->", message);
                mailMessage.Subject = Subject;
                mailMessage.IsBodyHtml = true;
                mailMessage.Body = messageformat;
                mailClient.Send(mailMessage);
                bResult = true;
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "EmailClass", "Code= 0, Flag=ALL", BusinessCont.FailStatus, ex.Message);
                throw ex;
            }
            finally
            {
                if (mailClient != null)
                    mailClient.Dispose();

                if (mailMessage != null)
                    mailMessage.Dispose();

                if (attachment1 != null)
                    attachment1.Dispose();
            }

            return bResult;
        }
    }
}