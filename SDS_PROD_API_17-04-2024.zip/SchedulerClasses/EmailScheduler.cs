﻿using Aadyam.SDS.API.Controllers;
using Aadyam.SDS.Business.BusinessConstant;
using Aadyam.SDS.Business.Model.GeoCoordinates;
using Quartz;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class EmailScheduler : BaseApiController, IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            int AppConfigAPITimeout = 0;
            bool SendMail;
            string InsertedtablesDetails = "";
            EmailClass model = new EmailClass();
            List<SADetails> SAList = new List<SADetails>();
            List<DistributorStatusDetails> DistList = new List<DistributorStatusDetails>();
            try
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "SchedulerEmail", "Scheduler Execution Start", BusinessCont.SuccessStatus, null);
                var AppConfig = BusinessCont.GetAppConfiguration();
                AppConfigAPITimeout = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigAPITimeout).Select(a => a.Value).FirstOrDefault());
                SAList = _unitOfWork.geoCoordinateRepository.GetSADetailsForEmailScheduler("Y", "SO", AppConfigAPITimeout);
                if (SAList != null && SAList.Count > 0)
                {
                    for (int i = 0; i < SAList.Count; i++)
                    {
                        DistList = _unitOfWork.geoCoordinateRepository.GetDistributorStatusForEmailScheduler(SAList[i].Code, 0, AppConfigAPITimeout);
                        int Count = 1;
                        if (DistList != null && DistList.Count > 0)
                        {
                            DataTable dt = new DataTable();
                            dt.Columns.AddRange(new DataColumn[16] { new DataColumn("Sr.No.", typeof(string)),
                            new DataColumn("Code", typeof(string)),
                            new DataColumn("Name", typeof(string)),
                            new DataColumn("Step1",typeof(string)),
                            new DataColumn("Step2", typeof(string)),
                            new DataColumn("Step3", typeof(string)),
                            new DataColumn("Step4", typeof(string)),
                            new DataColumn("Step5", typeof(string)),
                            new DataColumn("Step6", typeof(string)),
                            new DataColumn("Step7", typeof(string)),
                            new DataColumn("Step8", typeof(string)),
                            new DataColumn("Verified", typeof(string)),
                            new DataColumn("NotVerified", typeof(string)),
                            new DataColumn("Not Verified %", typeof(string)),
                            new DataColumn("Stage1 Status", typeof(string)),
                            new DataColumn("Stage 2 Status", typeof(string))
                            });
                            for (int j = 0; j < DistList.Count; j++)
                            {
                                dt.Rows.Add(Count, DistList[j].JDEDistributorCode, DistList[j].DistributorName, DistList[j].Step1Text, DistList[j].Step2Text, DistList[j].Step3Text, DistList[j].Step4Text, DistList[j].Step5Text, DistList[j].Step6Text, DistList[j].Step7Text, DistList[j].Step8Text, DistList[j].Verified, DistList[j].notVerified, DistList[j].NotverifiedPercent, DistList[j].Stage1StatusText, DistList[j].stage2Statustext);
                                Count++;
                            }
                            StringBuilder sb = new StringBuilder();
                            //Table start.
                            sb.Append("<table cellpadding='5' cellspacing='0' style='border: 1px solid #ccc;font-size: 9pt;font-family:Arial'>");

                            //Adding HeaderRow.
                            sb.Append("<tr>");
                            foreach (DataColumn column in dt.Columns)
                            {
                                sb.Append("<th style='background-color: #B8DBFD;border: 1px solid #ccc'>" + column.ColumnName + "</th>");
                            }
                            sb.Append("</tr>");


                            //Adding DataRow.
                            foreach (DataRow row in dt.Rows)
                            {
                                sb.Append("<tr>");
                                foreach (DataColumn column in dt.Columns)
                                {
                                    string icon = "";                                    
                                    sb.Append("<td style='width:100px;border: 1px solid #ccc'>" + row[column.ColumnName].ToString() + icon + "</td>");
                                }
                                sb.Append("</tr>");
                            }

                            //Table end.
                            sb.Append("</table>");
                            InsertedtablesDetails += sb;
                            //InsertedtablesDetails += "</tr></table>";
                            if (InsertedtablesDetails != "" && InsertedtablesDetails != null)
                            {
                                SendMail = model.SendEmails(SAList[i].Email,"","", "", InsertedtablesDetails);
                            }
                        }
                    }
                }
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "SchedulerEmail", "Scheduler Execution End", BusinessCont.SuccessStatus, null);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "SchedulerEmail", "Code= 0, Flag=ALL", BusinessCont.FailStatus, ex.Message);
                throw ex;
            }
        }
    }
}