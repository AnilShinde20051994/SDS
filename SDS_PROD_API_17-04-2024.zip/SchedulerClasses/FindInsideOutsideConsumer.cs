﻿using Aadyam.SDS.API.Controllers;
using Aadyam.SDS.Business.BusinessConstant;
using Quartz;
using System;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class FindInsideOutsideConsumer : BaseApiController, IJob
    {        
        public void Execute(IJobExecutionContext context)
        {
            try
            {
                int CompletedDist = 0;
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "FindInsideOutsideConsumer - Scheduler", "Find Inside/Outside Consumer Start", BusinessCont.SuccessStatus, null);
                CompletedDist = _unitOfWork.geoCoordinateRepository.DistwiseUpdateInsideOutsideFlag("ALL");
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "FindInsideOutsideConsumer - Scheduler", "Find Inside/Outside Consumer End", BusinessCont.SuccessStatus, "Finding Completed Distrbutor Count = "+ CompletedDist);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "FindInsideOutsideConsumer - Scheduler", null, BusinessCont.FailStatus, ex.Message);
            }
        }
    }
}