﻿using Aadyam.SDS.API.Controllers;
using Aadyam.SDS.Business.BusinessConstant;
using Quartz;
using System;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class GenerateCoordinates: BaseApiController, IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            int retValue = 0;
            try
            {
                BusinessCont.SaveLog(0, 100, retValue, 0, 0, "GenerateCoordinates", "Scheduler - Code=0, Flag=ALL", "START", "");
                retValue = _unitOfWork.geoCoordinateRepository.GenerateCoordinates("0", "ALL");
                BusinessCont.SaveLog(0, 100, retValue, 0, 0, "GenerateCoordinates", "Scheduler - Code=0, Flag=ALL", "END", "");
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, retValue, 0, 0, "SchedulerGenerateCoordinates", "Code=0, Flag=ALL", BusinessCont.FailStatus, ex.Message);
            }
        }
    }
}