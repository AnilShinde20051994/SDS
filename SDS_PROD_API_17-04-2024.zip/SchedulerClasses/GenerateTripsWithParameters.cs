﻿using Aadyam.SDS.API.Controllers;
using Aadyam.SDS.Business.BusinessConstant;
using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class GenerateTripsWithParameters : BaseApiController, IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            try
            {
                BusinessCont.SaveTripAuditLog(0, 100, 0, 0, 0, "Scheduler-GenerateTripWithNewParameters", "START", BusinessCont.SuccessStatus, null);
                _unitOfWork._tripRepository.GenerateTripWithNewParameters();
                BusinessCont.SaveTripAuditLog(0, 100, 0, 0, 0, "Scheduler-GenerateTripWithNewParameters", "END", BusinessCont.SuccessStatus, null);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveTripAuditLog(0, 100, 0, 0, 0, "GenerateTripWithNewParameters", null, BusinessCont.FailStatus, ex.Message);
            }
        }
    }
}