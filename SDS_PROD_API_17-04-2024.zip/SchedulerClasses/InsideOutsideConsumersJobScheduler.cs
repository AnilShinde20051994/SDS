﻿using Aadyam.SDS.Business.BusinessConstant;
using Aadyam.SDS.Business.Model.GeoCoordinates;
using Newtonsoft.Json;
using Quartz;
using Quartz.Impl;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class InsideOutsideConsumersJobScheduler
    {
        //public static void InsideOutsideConsumersStartJob(GetDistributorClusterList model)
        //{
        //    int InsideOutsideConsumersWithIntervalInHours = 0, InsideOutsideConsumersHours = 0, InsideOutsideConsumersMinutes = 0;

        //    try
        //    {
        //        BusinessCont.SaveLog(0, 100, 0, 0, 0, "InsideOutsideConsumersStartJob - Scheduler", "-- START --", "", null);

        //        var AppConfig = BusinessCont.GetAppConfiguration();   
        //        if (AppConfig != null)
        //        {
        //            BusinessCont.SaveLog(0, 100, 0, 0, 0, "AppConfig", "Start", "", null);

        //            InsideOutsideConsumersWithIntervalInHours = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigInsideOutsideConsumersWithIntervalInHours).Select(a => a.Value).FirstOrDefault());
        //            InsideOutsideConsumersHours = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigInsideOutsideConsumersHours).Select(a => a.Value).FirstOrDefault());
        //            InsideOutsideConsumersMinutes = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigInsideOutsideConsumersMinutes).Select(a => a.Value).FirstOrDefault());

        //            BusinessCont.SaveLog(0, 100, 0, 0, 0, "AppConfig", "End", "", null);
        //        }

        //        IScheduler IScheduler = StdSchedulerFactory.GetDefaultScheduler();
        //        IScheduler.Start();
        //        IJobDetail jobScheduler =JobBuilder.Create<InsideOutsideConsumersScheduler>().UsingJobData("InsideOutsideConsumersData", JsonConvert.SerializeObject(model))
        //        .Build();
        //        ITrigger triggerScheduler = TriggerBuilder.Create()
        //        .WithDailyTimeIntervalSchedule(s => s.WithIntervalInHours(InsideOutsideConsumersWithIntervalInHours)
        //        .OnEveryDay()
        //        .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(InsideOutsideConsumersHours, InsideOutsideConsumersMinutes)))
        //        .Build();
        //        IScheduler.ScheduleJob(jobScheduler, triggerScheduler);

        //        BusinessCont.SaveLog(0, 100, 0, 0, 0, "InsideOutsideConsumersStartJob - Scheduler", "-- END --", "", null);
        //    }
        //    catch(Exception ex)
        //    {
        //        BusinessCont.SaveLog(0, 100, 0, 0, 0, "InsideOutsideConsumersStartJob - JobScheduler", "", BusinessCont.FailStatus, BusinessCont.ExceptionMsg(ex.InnerException));
        //    }
        //}

        //public static void InsideOutsideConsumersDeleteJob()
        //{
        //    try
        //    {
        //        BusinessCont.SaveLog(0, 100, 0, 0, 0, "DeleteJobInsideOutsideConsumers - Scheduler", "Start", "", null);
        //        var scheduler = StdSchedulerFactory.GetDefaultScheduler();
        //        scheduler.Clear();
        //        scheduler.Shutdown();
        //        BusinessCont.SaveLog(0, 100, 0, 0, 0, "DeleteJobInsideOutsideConsumers - Scheduler", "End", BusinessCont.SuccessStatus, null);
        //    }
        //    catch (Exception ex)
        //    {
        //        BusinessCont.SaveLog(0, 100, 0, 0, 0, "DeleteJobInsideOutsideConsumers - JobScheduler", "", BusinessCont.FailStatus, ex.Message);
        //    }
        //}

    }
}