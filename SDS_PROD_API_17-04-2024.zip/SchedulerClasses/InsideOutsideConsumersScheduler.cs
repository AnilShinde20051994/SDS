﻿using Aadyam.SDS.API.Controllers;
using Aadyam.SDS.Business.BusinessConstant;
using Aadyam.SDS.Business.Model.GeoCoordinates;
using Quartz;
using System;
using System.Collections.Generic;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class InsideOutsideConsumersScheduler : BaseApiController, IJob
    {
        int InsertedCount = 0;
        List<GetDistributorClusterList> result = new List<GetDistributorClusterList>(); // new array
        public void Execute(IJobExecutionContext context)
        {
            try
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "InsideOutsideConsumersScheduler", "Start", "", null);
                
                result = _unitOfWork.geoCoordinateRepository.GetDistributorClusterList();
                if (result.Count > 0)
                {
                    foreach (var i in result)
                    {
                        InsertedCount = _unitOfWork.geoCoordinateRepository.CheckInsideOrOutsideConsumers(i.DistributorID, i.ClusterID);
                    }
                }
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "InsideOutsideConsumersScheduler - Scheduler", "End", "", null);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "InsideOutsideConsumersScheduler - Scheduler", "InsertedCount = " + InsertedCount, BusinessCont.FailStatus, ex.Message);
            }
        }
    }
}