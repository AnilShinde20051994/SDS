﻿using Aadyam.SDS.Business.Model.Context;
using Aadyam.SDS.Business.Model.GeoCoordinates;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using Newtonsoft.Json;
using Aadyam.SDS.Business.BusinessConstant;
using GeoJSON.Net;
using System.Data.Entity.Core.Objects;
using Newtonsoft.Json.Linq;
using System.Net;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class JSONConverterTO
    {
        // Return Save Area coordinates       
        public int SaveAreaGeoCoordinates()
        {
            return SaveAreaGeoCoordinatesPvt();
        }

        public void ReadAllJSON(string filepath)
        {
            using (var strreader = new StreamReader(filepath))
            {
                using (var reader = new JsonTextReader(strreader))
                {
                    while (reader.Read())
                    {
                        if (reader.TokenType == JsonToken.StartObject)
                        {
                            var account = JObject.Load(reader);
                            //GYJ tiene atributo type que puede ser Cliente o Sucursal
                            var accountType = account.GetValue("Type");
                            if (accountType != null && accountType.HasValues)
                            {
                                if (accountType.Value<string>() == "Cliente")
                                {
                                    Console.WriteLine("Procesando cliente");
                                }
                                else if (accountType.Value<string>() == "Sucursal")
                                {
                                    Console.WriteLine("Procesando sucursal (TODO)");
                                    //TODO: Cargar sucursales
                                }
                            }
                            else
                            {

                                //Si no hay valor se toma como cuenta
                                //Para otras implementaciones que no sean GYJ

                                Console.WriteLine("Procesando cliente");
                            }


                        }
                    }
                }
            }
        }

        private int SaveAreaGeoCoordinatesPvt()
        {
            string JSONStr = string.Empty;
            int counter = 0;
            try
            {
                using (SDSDBEntities contextManager = new SDSDBEntities())
                {
                    string Filepath = "D:/Fensings/IND-UP-Gaziyabad.geojson";
                    //ReadAllJSON(Filepath);
                    string State = "UttarPradesh";
                    string StCode = "UP";

                    var josnData = File.ReadAllText(Filepath);
                    var reader = new NetTopologySuite.IO.GeoJsonReader();
                    var featureCollection = reader.Read<GeoJSON.Net.Feature.FeatureCollection>(josnData);
                    ObjectParameter parameter = null;
                    parameter = new ObjectParameter("MapId", typeof(long));
                    


                    for (int fIndex = 0; fIndex < featureCollection.Features.Count; fIndex++)
                    {
                        var AreaDetails = featureCollection.Features[fIndex].Properties;
                        List<LocationDetails> locationDetailsList = new List<LocationDetails>();
                        AreaDetails areaDetails = new AreaDetails();
                        string DCode = string.Empty; string TCode = string.Empty; string ACode = string.Empty;
                        areaDetails.State = State;
                        for (int AIndex = 0; AIndex < AreaDetails.Count; AIndex++)
                        {
                            var element = AreaDetails.ElementAt(AIndex);
                            var Key = element.Key;
                            var Value = element.Value;
                            //if (Key == "state")
                            //{
                            //    State = element.Value.ToString();
                            //}
                            if (Key == "Admin3")
                            {
                                areaDetails.District = element.Value.ToString();
                            }
                            if (Key == "Admin5")
                            {
                                areaDetails.Taluka = element.Value.ToString();
                            }
                            //if (Key == "Ward_No" || Key == "Ward_No" || Key == "NAME_12" || Key == "VILL_NAME" || Key == "NAME_12_13" || Key == "DMV_N" || Key == "Ward Name")
                            //{
                            if (Key == "Admin7")
                            {
                                if (Value != null && Value.ToString() != "")
                                {
                                    areaDetails.AreaName = Value.ToString();
                                    //areaDetails.Taluka = "Mysore";
                                    //areaDetails.District = "Mysore";
                                }
                            }
                            //if (Key == "description")
                            //{
                            //    //XDocument xDoc = XDocument.Load(Value.ToString());
                            //    XmlDocument xml = new XmlDocument();
                            //    xml.LoadXml(Value.ToString());
                            //    XmlNodeList xnList = xml.SelectNodes("/ul/li");
                            //    foreach (XmlNode m in xnList)
                            //    {
                            //        var InnerData = m.ChildNodes;
                            //        var KeyParam = InnerData[0].InnerText;
                            //        var ValueParam = InnerData[1].InnerText;
                            //        if (KeyParam == "DIST_NAME")
                            //        {
                            //            if (ValueParam != null)
                            //            {
                            //                areaDetails.District = ValueParam.ToString();
                            //            }
                            //        }
                            //        else if (KeyParam == "TEHS_NAME")
                            //        {
                            //            if (ValueParam != null)
                            //            {
                            //                areaDetails.Taluka = ValueParam.ToString();
                            //            }
                            //        }
                            //        else if (KeyParam == "NAME")
                            //        {
                            //            if (ValueParam != null)
                            //            {
                            //                areaDetails.AreaName = ValueParam.ToString();
                            //            }
                            //        }
                            //        //Console.WriteLine(InnerData);
                            //        //Console.WriteLine(m.GetType["span"].Value);
                            //    }
                            //}
                            //else

                            //if (Value != null)
                            //{
                            //    areaDetails.District = "Kaushambi";
                            //}
                            //if (Value != null)
                            //{
                            //    areaDetails.Taluka = "Sirathu";
                            //}
                            //if(Key == "DISTRICT")
                            //{
                            //    if(Value.ToString()=="9")
                            //    {
                            //        Flag = true;
                            //    }
                            //    else
                            //    {
                            //        Flag = false;
                            //    }
                            //}
                            //if (Key == "Dist_Name" || Key == "DISTRICT_N" || Key == "district")
                            //{
                            //    if (Value != null)
                            //    {
                            //        areaDetails.District = Value.ToString();
                            //    }
                            //}
                            // if (Key == "SUB_DISTRICT" || Key == "SUB_DIST" || Key == "TALUK" || Key == "Thsil_Name" || Key == "sub_dist")
                            //{
                            //    if (Value != null && Value.ToString() == "1")
                            //    {
                            //        areaDetails.Taluka = "Sirathu";
                            //    }
                            //    else if (Value != null && Value.ToString() == "2")
                            //    {
                            //        areaDetails.Taluka = "Manjhanpur";
                            //    }
                            //    else if (Value != null && Value.ToString() == "3")
                            //    {
                            //        areaDetails.Taluka = "Chail";
                            //    }
                            //}

                        }

                        if (!string.IsNullOrEmpty(areaDetails.AreaName) && !string.IsNullOrEmpty(areaDetails.District) && !string.IsNullOrEmpty(areaDetails.Taluka))
                        {
                            areaDetails.StateCode = "UP";
                            DCode = areaDetails.District.Substring(0, 3).ToUpper();
                            areaDetails.DistrictCode = StCode + areaDetails.District + "DT";
                            areaDetails.TalukaCode = StCode + DCode + areaDetails.Taluka;
                            string TempAreaCode = StCode + areaDetails.AreaName + fIndex.ToString();
                            TempAreaCode = Regex.Replace(TempAreaCode, @"\s+", "");
                            areaDetails.AreaCode = TempAreaCode;

                            var AreaCoords = featureCollection.Features[fIndex].Geometry;
                            var Type = AreaCoords.Type;
                            if (Type == GeoJSONObjectType.Polygon)
                            {
                                var polygon = AreaCoords as GeoJSON.Net.Geometry.Polygon;
                                var polygonCoords = polygon.Coordinates[0].Coordinates;
                                for (int cIndex = 0; cIndex < polygonCoords.Count; cIndex++)
                                {
                                    LocationDetails locationDetails = new LocationDetails();
                                    locationDetails.lat = Convert.ToDecimal(polygonCoords[cIndex].Latitude);
                                    locationDetails.lng = Convert.ToDecimal(polygonCoords[cIndex].Longitude);
                                    locationDetailsList.Add(locationDetails);
                                }
                            }

                            if (Type == GeoJSONObjectType.MultiPolygon)
                            {
                                var polygon = AreaCoords as GeoJSON.Net.Geometry.MultiPolygon;
                                var polygonCoords = polygon.Coordinates[0].Coordinates;
                                for (int cIndex = 0; cIndex < polygonCoords[0].Coordinates.Count; cIndex++)
                                {
                                    LocationDetails locationDetails = new LocationDetails();
                                    locationDetails.lat = Convert.ToDecimal(polygonCoords[0].Coordinates[cIndex].Latitude);
                                    locationDetails.lng = Convert.ToDecimal(polygonCoords[0].Coordinates[cIndex].Longitude);
                                    locationDetailsList.Add(locationDetails);
                                }
                            }
                            areaDetails.AreaCoordinates = null;
                            areaDetails.AreaCoordinates = locationDetailsList;
                            JSONStr = string.Empty;
                            JSONStr = JsonConvert.SerializeObject(areaDetails);
                        }
                        try
                        {
                            if (!string.IsNullOrEmpty(JSONStr) && !string.IsNullOrEmpty(areaDetails.AreaCode) && !string.IsNullOrEmpty(areaDetails.DistrictCode) && !string.IsNullOrEmpty(areaDetails.TalukaCode))
                            {
                                contextManager.usp_AddAllMuncipalAreaCoordinates(0,
                                    areaDetails.StateCode, areaDetails.State,
                                    areaDetails.DistrictCode, areaDetails.District,
                                    areaDetails.TalukaCode, areaDetails.Taluka,
                                   areaDetails.AreaCode, areaDetails.AreaName,
                                    JSONStr, parameter);
                                counter++;
                            }
                        }
                        catch (Exception ex)
                        {
                            BusinessCont.SaveLog(0, 0, 0, 0, 0, null, JsonConvert.ToString(areaDetails), BusinessCont.FailStatus, "Exception= " + ex.ToString() + ",  Inner Exception= " + ex.InnerException?.ToString() ?? "");
                            throw ex;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, 0, 0, 0, null, null, BusinessCont.FailStatus, "Exception= " + ex.ToString() + ",  Inner Exception= " + ex.InnerException?.ToString() ?? "");
                throw ex;
            }
            return counter;
        }
    }
}