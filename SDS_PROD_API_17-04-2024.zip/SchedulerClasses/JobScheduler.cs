﻿using Aadyam.SDS.Business.BusinessConstant;
using Quartz;
using Quartz.Impl;
using System;
using System.Linq;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class JobScheduler
    {
        public static void Start()
        {
            int WithIntervalInHours = 0, Hours = 0, Minutes = 0, WithIntervalInHoursEmail = 0, TripWithIntervalInHours = 0, HoursEmail = 0, MinutesEmail = 0, TripHours = 0, TripMinutes = 0, UpdateGCWithIntervalInHours = 0, UpdateGCHours = 0, UpdateGCMinutes = 0, WithIntervalInHoursDaily = 0, HoursDaily = 0, MinutesDaily = 0, WithIntervalInHoursConsumerStatus = 0, HoursConsumerStatus = 0, MinutesConsumerStatus = 0, InsideOutsideConsumersWithIntervalInHours = 0, InsideOutsideConsumersHours = 0, InsideOutsideConsumersMinutes = 0, WithIntervalInHoursPilot = 0, HoursPilot = 0, MinutesPilot = 0, WithIntervalInHoursPilotSch = 0, HoursPilotSch = 0, MinutesPilotSch = 0, WithIntervalTripReptSch = 0, HoursTripReptSch = 0, MinutesTripReptSch = 0;
            int WithIntervalInHoursFindInsideOutside = 0, HoursFindInsideOutside = 0, MinutesFindInsideOutside = 0, UpdateCLWithIntervalInHours = 0, UpdateCLHours = 0, UpdateCLMinutes = 0, HoursTripReptSchInvalid = 0, WithIntervalTripReptSchInvalid = 0, MinutesTripReptSchInvalid = 0, HoursProcessData = 0, WithIntervalProcessData = 0, MinutesProcessData = 0;
            string IsGenerateCordSchExecute = string.Empty, IsEmailSchExecute = string.Empty, IsDailySchExecute = string.Empty, IsGenerateTripSchExecute = string.Empty, IsUpdateGCSchExecute = string.Empty, IsFindInsideOutsideSchExecute = string.Empty, IsUpdateCLSchExecute = string.Empty, IsConsumerStatusSchExecute = string.Empty, IsCheckInsideOutsideConsumersExecute = string.Empty, IsPilotSchExecute = string.Empty, IsPilotSchSchExecute = string.Empty, IsTripReptSchExecute = string.Empty, IsTripReptSchExecuteInvalid = string.Empty, IsDataProcessExecute = string.Empty;
            int CheckLatestGCHours = 0, CheckLatestUpdateGCMinutes = 0, CheckLatestGCWithIntervalInHours = 0; string IsCheckLatestGCSchExecute = string.Empty;
            int UpdateSecGCHours = 0, UpdateSecGCMinutes = 0, UpdateSecGCWithIntervalInHours = 0; string IsUpdateSecGCSchExecute = string.Empty;
            int GenTripHours = 0, GenTripMinutes = 0, GenTripWithIntervalInHours = 0;  string GenTripSchExecute = string.Empty;
            try                  
            {
                var AppConfig = BusinessCont.GetAppConfiguration();
                if (AppConfig != null)
                {
                    // Generate Coordinates Scheduler
                    WithIntervalInHours = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigWithIntervalInHours).Select(a => a.Value).FirstOrDefault());
                    Hours = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigHours).Select(a => a.Value).FirstOrDefault());
                    Minutes = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigMinutes).Select(a => a.Value).FirstOrDefault());
                    IsGenerateCordSchExecute = AppConfig.Where(a => a.Key == BusinessCont.AppConfigIsSchExecute).Select(a => a.Value).FirstOrDefault();

                    // Email Send Scheduler - Onboarding
                    WithIntervalInHoursEmail = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigEmailWithIntervalInHours).Select(a => a.Value).FirstOrDefault());
                    HoursEmail = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigEmailHours).Select(a => a.Value).FirstOrDefault());
                    MinutesEmail = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigEmailMinutes).Select(a => a.Value).FirstOrDefault());
                    IsEmailSchExecute = AppConfig.Where(a => a.Key == BusinessCont.AppConfigIsEmailSchExecute).Select(a => a.Value).FirstOrDefault();

                    // Trip Scheduler
                    TripHours = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigTripHours).Select(a => a.Value).FirstOrDefault());
                    TripMinutes = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigTripMinutes).Select(a => a.Value).FirstOrDefault());
                    IsGenerateTripSchExecute = AppConfig.Where(a => a.Key == BusinessCont.AppConfigIsGenerateTripSchExecute).Select(a => a.Value).FirstOrDefault();
                    TripWithIntervalInHours = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigTripWithIntervalInHours).Select(a => a.Value).FirstOrDefault());

                    // For Update GC Scheduler
                    UpdateGCHours  = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigUpdateGCHours).Select(a => a.Value).FirstOrDefault());
                    UpdateGCMinutes = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigUpdateGCMinutes).Select(a => a.Value).FirstOrDefault());
                    IsUpdateGCSchExecute = AppConfig.Where(a => a.Key == BusinessCont.AppConfigIsUpdateGCSchExecute).Select(a => a.Value).FirstOrDefault();
                    UpdateGCWithIntervalInHours = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigUpdateGCWithIntervalInHours).Select(a => a.Value).FirstOrDefault());

                    // For Update CL Scheduler
                    UpdateCLHours = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigUpdateCLHours).Select(a => a.Value).FirstOrDefault());
                    UpdateCLMinutes = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigUpdateCLMinutes).Select(a => a.Value).FirstOrDefault());
                    IsUpdateCLSchExecute = AppConfig.Where(a => a.Key == BusinessCont.AppConfigIsUpdateCLSchExecute).Select(a => a.Value).FirstOrDefault();
                    UpdateCLWithIntervalInHours = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigUpdateCLWithIntervalInHours).Select(a => a.Value).FirstOrDefault());

                    // Daily Scheduler for Data Insertion
                    WithIntervalInHoursDaily = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigDailyWithIntervalInHours).Select(a => a.Value).FirstOrDefault());
                    HoursDaily = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigDailyHours).Select(a => a.Value).FirstOrDefault());
                    MinutesDaily = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigDailyMinutes).Select(a => a.Value).FirstOrDefault());
                    IsDailySchExecute = AppConfig.Where(a => a.Key == BusinessCont.AppConfigIsDailySchExecute).Select(a => a.Value).FirstOrDefault();

                    // Find Inside/Outside consumer
                    WithIntervalInHoursFindInsideOutside = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigWithIntervalInHoursFindInsideOutside).Select(a => a.Value).FirstOrDefault());
                    HoursFindInsideOutside = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigHoursFindInsideOutside).Select(a => a.Value).FirstOrDefault());
                    MinutesFindInsideOutside = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigMinutesFindInsideOutside).Select(a => a.Value).FirstOrDefault());
                    IsFindInsideOutsideSchExecute = AppConfig.Where(a => a.Key == BusinessCont.AppConfigIsFindInsideOutsideSchExecute).Select(a => a.Value).FirstOrDefault();
                    IsCheckInsideOutsideConsumersExecute = AppConfig.Where(a => a.Key == BusinessCont.AppConfigCheckInsideOutsideConsumersExecute).Select(a => a.Value).FirstOrDefault();

                    // Consumer Verification Status Save & Get
                    WithIntervalInHoursConsumerStatus = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigConsumerStatusWithIntervalInHours).Select(a => a.Value).FirstOrDefault());
                    HoursConsumerStatus = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigConsumerStatusHours).Select(a => a.Value).FirstOrDefault());
                    MinutesConsumerStatus = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigConsumerStatusMinutes).Select(a => a.Value).FirstOrDefault());
                    IsConsumerStatusSchExecute = AppConfig.Where(a => a.Key == BusinessCont.AppConfigIsConsumerStatusSchExecute).Select(a => a.Value).FirstOrDefault();

                    // Check Inside-Outside Scheduler
                    InsideOutsideConsumersWithIntervalInHours = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigInsideOutsideConsumersWithIntervalInHours).Select(a => a.Value).FirstOrDefault());
                    InsideOutsideConsumersHours = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigInsideOutsideConsumersHours).Select(a => a.Value).FirstOrDefault());
                    InsideOutsideConsumersMinutes = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigInsideOutsideConsumersMinutes).Select(a => a.Value).FirstOrDefault());

                    // PilotReport
                    WithIntervalInHoursPilot = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigPilotWithIntervalInHours).Select(a => a.Value).FirstOrDefault());
                    HoursPilot = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigPilotHours).Select(a => a.Value).FirstOrDefault());
                    MinutesPilot = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigPilotMinutes).Select(a => a.Value).FirstOrDefault());
                    IsPilotSchExecute = AppConfig.Where(a => a.Key == BusinessCont.AppConfigIsPilotSchExecute).Select(a => a.Value).FirstOrDefault();

                    // PilotReportScheduler
                    WithIntervalInHoursPilotSch = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigPilotSchWithIntervalInHours).Select(a => a.Value).FirstOrDefault());
                    HoursPilotSch = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigPilotSchHours).Select(a => a.Value).FirstOrDefault());
                    MinutesPilotSch = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigPilotSchMinutes).Select(a => a.Value).FirstOrDefault());
                    IsPilotSchSchExecute = AppConfig.Where(a => a.Key == BusinessCont.AppConfigIsPilotSchSchExecute).Select(a => a.Value).FirstOrDefault();

                    // Trip Generation Report
                    WithIntervalTripReptSch = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigTripReptSchWithIntervalInHours).Select(a => a.Value).FirstOrDefault());
                    HoursTripReptSch = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigTripReptSchHours).Select(a => a.Value).FirstOrDefault());
                    MinutesTripReptSch = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigTripReptSchMinutes).Select(a => a.Value).FirstOrDefault());
                    IsTripReptSchExecute = AppConfig.Where(a => a.Key == BusinessCont.AppConfigIsTripReptSchExecute).Select(a => a.Value).FirstOrDefault();

                    // Trip Generation Invalid  Clusterwise Report
                    WithIntervalTripReptSchInvalid = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigTripReptSchWithIntervalInHoursInv).Select(a => a.Value).FirstOrDefault());
                    HoursTripReptSchInvalid = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigTripReptSchHoursInv).Select(a => a.Value).FirstOrDefault());
                    MinutesTripReptSchInvalid = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigTripReptSchMinutesInv).Select(a => a.Value).FirstOrDefault());
                    IsTripReptSchExecuteInvalid = AppConfig.Where(a => a.Key == BusinessCont.AppConfigIsTripReptSchExecuteInv).Select(a => a.Value).FirstOrDefault();

                    //Data Process Report
                    WithIntervalProcessData = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigDataProcessWithIntervalInHours).Select(a => a.Value).FirstOrDefault());
                    HoursProcessData = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigDataProcessHours).Select(a => a.Value).FirstOrDefault());
                    MinutesProcessData = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigDataProcessMinutes).Select(a => a.Value).FirstOrDefault());
                    IsDataProcessExecute = AppConfig.Where(a => a.Key == BusinessCont.AppConfigDataProcessIsExecute).Select(a => a.Value).FirstOrDefault();

                    // For Check Latest GC Hours
                    CheckLatestGCHours = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigCheckLatestGCHours).Select(a => a.Value).FirstOrDefault());
                    CheckLatestUpdateGCMinutes = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigCheckLatestGCMinutes).Select(a => a.Value).FirstOrDefault());
                    IsCheckLatestGCSchExecute = AppConfig.Where(a => a.Key == BusinessCont.AppConfigIsCheckLatestGCSchExecute).Select(a => a.Value).FirstOrDefault();
                    CheckLatestGCWithIntervalInHours = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigCheckLatestGCWithIntervalInHours).Select(a => a.Value).FirstOrDefault());

                    // Update Second GC Data In Bulk
                    UpdateSecGCHours = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigUpdateSecGCHours).Select(a => a.Value).FirstOrDefault());
                    UpdateSecGCMinutes = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigUpdateSecGCMinutes).Select(a => a.Value).FirstOrDefault());
                    IsUpdateSecGCSchExecute = AppConfig.Where(a => a.Key == BusinessCont.AppConfigIsUpdateSecGCSchExecute).Select(a => a.Value).FirstOrDefault();
                    UpdateSecGCWithIntervalInHours = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigUpdateSecGCWithIntervalInHours).Select(a => a.Value).FirstOrDefault());

                    // Generate Trips With New Parameters
                    GenTripHours = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigGenTripHours).Select(a => a.Value).FirstOrDefault());
                    GenTripMinutes = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigGenTripMinutes).Select(a => a.Value).FirstOrDefault());
                    GenTripSchExecute = AppConfig.Where(a => a.Key == BusinessCont.AppConfigIsGenTripSchExecute).Select(a => a.Value).FirstOrDefault();
                    GenTripWithIntervalInHours = Convert.ToInt32(AppConfig.Where(a => a.Key == BusinessCont.AppConfigGenTripWithIntervalInHours).Select(a => a.Value).FirstOrDefault());
                }

                // Generate Coordinates Scheduler
                if (Hours > 0 && WithIntervalInHours > 0 && IsGenerateCordSchExecute == "Y")
                {
                    IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                    scheduler.Start();
                    IJobDetail job = JobBuilder.Create<GenerateCoordinates>().Build();
                    ITrigger trigger = TriggerBuilder.Create()
                        .WithDailyTimeIntervalSchedule
                          (s =>
                             s.WithIntervalInHours(WithIntervalInHours)
                            .OnEveryDay()
                            .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(Hours, Minutes))
                          )
                        .Build();
                    scheduler.ScheduleJob(job, trigger);
                }

                // Email Send Scheduler
                if (HoursEmail > 0 && WithIntervalInHoursEmail > 0 && IsEmailSchExecute=="Y")
                {
                    IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                    scheduler.Start();
                    IJobDetail job = JobBuilder.Create<OnboardingEmailScheduler>().Build();
                    ITrigger trigger = TriggerBuilder.Create()
                       .WithDailyTimeIntervalSchedule
                         (s =>
                            s.WithIntervalInHours(WithIntervalInHoursEmail)
                           .OnEveryDay()
                           .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(HoursEmail, MinutesEmail))
                         )
                       .Build();
                    scheduler.ScheduleJob(job, trigger);
                }

                // Daily Scheduler Check
                if (HoursDaily > 0 && WithIntervalInHoursDaily > 0 && IsDailySchExecute == "Y")
                {
                    IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                    scheduler.Start();
                    IJobDetail job = JobBuilder.Create<DailySchedulerCheck>().Build();
                    ITrigger trigger = TriggerBuilder.Create()
                        .WithDailyTimeIntervalSchedule
                          (s =>
                             s.WithIntervalInHours(WithIntervalInHoursDaily)
                            .OnEveryDay()
                            .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(HoursDaily, MinutesDaily))
                          )
                        .Build();
                    scheduler.ScheduleJob(job, trigger);
                }

                // Daily Consumer Verification Status Save
                if (HoursConsumerStatus > 0 && WithIntervalInHoursConsumerStatus > 0 && IsConsumerStatusSchExecute == "Y")
                {
                    IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                    scheduler.Start();
                    IJobDetail job = JobBuilder.Create<AddUpdateConsumerVerificationStatus>().Build();
                    ITrigger trigger = TriggerBuilder.Create()
                        .WithDailyTimeIntervalSchedule
                          (s =>
                             s.WithIntervalInHours(WithIntervalInHoursConsumerStatus)
                            .OnEveryDay()
                            .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(HoursConsumerStatus, MinutesConsumerStatus))
                          )
                        .Build();
                    scheduler.ScheduleJob(job, trigger);
                }

                // Daily Consumer Verification Status Save
                if (HoursConsumerStatus > 0 && WithIntervalInHoursConsumerStatus > 0 && IsConsumerStatusSchExecute == "Y")
                {
                    IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                    scheduler.Start();
                    IJobDetail job = JobBuilder.Create<AddUpdateConsumerVerificationStatus>().Build();
                    ITrigger trigger = TriggerBuilder.Create()
                        .WithDailyTimeIntervalSchedule
                          (s =>
                             s.WithIntervalInHours(WithIntervalInHoursConsumerStatus)
                            .OnEveryDay()
                            .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(HoursConsumerStatus + 7, MinutesConsumerStatus))
                          )
                        .Build();
                    scheduler.ScheduleJob(job, trigger);
                }

                // Daily Consumer Verification Status Send Email
                if (HoursConsumerStatus > 0 && WithIntervalInHoursConsumerStatus > 0 && IsConsumerStatusSchExecute == "Y")
                {
                    IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                    scheduler.Start();
                    IJobDetail job = JobBuilder.Create<ConsumerVerificationStatus>().Build();
                    ITrigger trigger = TriggerBuilder.Create()
                        .WithDailyTimeIntervalSchedule
                          (s =>
                             s.WithIntervalInHours(WithIntervalInHoursConsumerStatus)
                            .OnEveryDay()
                            .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(HoursConsumerStatus + 7, MinutesConsumerStatus + 10))
                          )
                        .Build();
                    scheduler.ScheduleJob(job, trigger);
                }

                // Generate Trips Scheduler
                if (TripHours > 0 && TripWithIntervalInHours > 0 && IsGenerateTripSchExecute == "Y")
                {
                    IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                    scheduler.Start();
                    IJobDetail job = JobBuilder.Create<TripPlanning>().Build();
                    ITrigger trigger = TriggerBuilder.Create()
                        .WithDailyTimeIntervalSchedule
                          (s =>
                             s.WithIntervalInHours(TripWithIntervalInHours)
                            .OnEveryDay()
                            .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(TripHours, TripMinutes))
                          )
                        .Build();
                    scheduler.ScheduleJob(job, trigger);
                }

                // Generate Update Google Coordinate Scheduler
                if (UpdateGCHours > 0 && UpdateGCWithIntervalInHours > 0 && IsUpdateGCSchExecute == "Y")
                {
                    IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                    scheduler.Start();
                    // Old GC
                    // IJobDetail job = JobBuilder.Create<UpdateGCScheduler>().Build();
                    // Update GC Scheduler New
                    IJobDetail job = JobBuilder.Create<UpdateGCSchedulerNew>().Build();
                    ITrigger trigger = TriggerBuilder.Create()
                        .WithDailyTimeIntervalSchedule
                          (s =>
                             s.WithIntervalInHours(UpdateGCWithIntervalInHours)
                            .OnEveryDay()
                            .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(UpdateGCHours, UpdateGCMinutes))
                          )
                        .Build();
                    scheduler.ScheduleJob(job, trigger);
                }

                // Generate Update Google Coordinate Scheduler
                if (UpdateCLHours > 0 && UpdateCLWithIntervalInHours > 0 && IsUpdateCLSchExecute == "Y")
                {
                    IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                    scheduler.Start();
                    IJobDetail job = JobBuilder.Create<UpdateAddressLocationInCDCMS>().Build();
                    ITrigger trigger = TriggerBuilder.Create()
                        .WithDailyTimeIntervalSchedule
                          (s =>
                             s.WithIntervalInHours(UpdateCLWithIntervalInHours)
                            .OnEveryDay()
                            .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(UpdateCLHours, UpdateCLMinutes))
                          )
                        .Build();
                    scheduler.ScheduleJob(job, trigger);
                }

                // Find Inside/Outside consumer
                if (MinutesFindInsideOutside > 0 && HoursFindInsideOutside > 0 && IsFindInsideOutsideSchExecute == "Y")
                {
                    IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                    scheduler.Start();
                    IJobDetail job = JobBuilder.Create<FindInsideOutsideConsumer>().Build();
                    ITrigger trigger = TriggerBuilder.Create()
                        .WithDailyTimeIntervalSchedule
                          (s =>
                             s.WithIntervalInHours(WithIntervalInHoursFindInsideOutside)
                            .OnEveryDay()
                            .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(HoursFindInsideOutside, MinutesFindInsideOutside))
                          )
                        .Build();
                    scheduler.ScheduleJob(job, trigger);
                }

                // Check Inside-Outside scheduler
                if (InsideOutsideConsumersHours > 0 && InsideOutsideConsumersMinutes > 0 && InsideOutsideConsumersWithIntervalInHours > 0 && IsCheckInsideOutsideConsumersExecute == "Y")
                {
                    IScheduler ISchedulerObj = StdSchedulerFactory.GetDefaultScheduler();
                    ISchedulerObj.Start();
                    IJobDetail jobSchedulerObj = JobBuilder.Create<InsideOutsideConsumersScheduler>()
                    .Build();
                    ITrigger triggerSchedulerObj = TriggerBuilder.Create()
                    .WithDailyTimeIntervalSchedule(s => s.WithIntervalInHours(InsideOutsideConsumersWithIntervalInHours)
                    .OnEveryDay()
                    .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(InsideOutsideConsumersHours, InsideOutsideConsumersMinutes)))
                    .Build();
                    ISchedulerObj.ScheduleJob(jobSchedulerObj, triggerSchedulerObj);
                }

                // Pilot Report
                if (HoursPilot > 0 && WithIntervalInHoursPilot > 0 && IsPilotSchExecute == "Y")
                {
                    IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                    scheduler.Start();
                    IJobDetail job = JobBuilder.Create<PilotReportMail>().Build();
                    ITrigger trigger = TriggerBuilder.Create()
                        .WithDailyTimeIntervalSchedule
                          (s =>
                             s.WithIntervalInHours(WithIntervalInHoursPilot)
                            .OnEveryDay()
                            .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(HoursPilot, MinutesPilot))
                          )
                        .Build();
                    scheduler.ScheduleJob(job, trigger);
                }

                // Pilot Scheduler Report
                if (HoursPilotSch > 0 && WithIntervalInHoursPilotSch > 0 && IsPilotSchSchExecute == "Y")
                {
                    IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                    scheduler.Start();
                    IJobDetail job = JobBuilder.Create<PilotReport>().Build();
                    ITrigger trigger = TriggerBuilder.Create()
                        .WithDailyTimeIntervalSchedule
                          (s =>
                             s.WithIntervalInHours(WithIntervalInHoursPilotSch)
                            .OnEveryDay()
                            .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(HoursPilotSch, MinutesPilotSch))
                          )
                        .Build();
                    scheduler.ScheduleJob(job, trigger);
                }

                // Trip Generation Report Scheduler 
                if (HoursTripReptSch > 0 && WithIntervalTripReptSch > 0 && IsTripReptSchExecute == "Y")
                {
                    IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                    scheduler.Start();
                    IJobDetail job = JobBuilder.Create<TripGenerationReport>().Build();
                    ITrigger trigger = TriggerBuilder.Create()
                        .WithDailyTimeIntervalSchedule
                          (s =>
                             s.WithIntervalInHours(WithIntervalTripReptSch)
                            .OnEveryDay()
                            .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(HoursTripReptSch, MinutesTripReptSch))
                          )
                        .Build();
                    scheduler.ScheduleJob(job, trigger);
                }

                // To Genrate Trip Invalid Clusterwise Report
                if (HoursTripReptSchInvalid > 0 && WithIntervalTripReptSchInvalid > 0 && IsTripReptSchExecuteInvalid == "Y")
                {
                    IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                    scheduler.Start();
                    IJobDetail job = JobBuilder.Create<TripGenInvalidClust>().Build();
                    ITrigger trigger = TriggerBuilder.Create()
                        .WithDailyTimeIntervalSchedule
                          (s =>
                             s.WithIntervalInHours(WithIntervalTripReptSchInvalid)
                            .OnEveryDay()
                            .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(HoursTripReptSchInvalid, MinutesTripReptSchInvalid))
                          )
                        .Build();
                    scheduler.ScheduleJob(job, trigger);
                }

                // Data Process Report
                if (HoursProcessData > 0 && WithIntervalProcessData > 0 && IsDataProcessExecute == "Y")
                {
                    IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                    scheduler.Start();
                    IJobDetail job = JobBuilder.Create<DataProcessReport>().Build();
                    ITrigger trigger = TriggerBuilder.Create()
                        .WithDailyTimeIntervalSchedule
                          (s =>
                             s.WithIntervalInHours(WithIntervalProcessData)
                            .OnEveryDay()
                            .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(HoursProcessData, MinutesProcessData))
                          )
                        .Build();
                    scheduler.ScheduleJob(job, trigger);
                }

                // Check Latest GC Scheduler
                if (CheckLatestGCHours > 0 && CheckLatestUpdateGCMinutes > 0 && CheckLatestGCWithIntervalInHours > 0 && IsCheckLatestGCSchExecute == "Y")
                {
                    IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                    scheduler.Start();
                    IJobDetail job = JobBuilder.Create<CheckLatestGCInsOut>().Build();
                    ITrigger trigger = TriggerBuilder.Create()
                        .WithDailyTimeIntervalSchedule
                          (s =>
                             s.WithIntervalInHours(CheckLatestGCWithIntervalInHours)
                            .OnEveryDay()
                            .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(CheckLatestGCHours, CheckLatestUpdateGCMinutes))
                          )
                        .Build();
                    scheduler.ScheduleJob(job, trigger);
                }

                // Update Latest GC Scheduler
                if (UpdateSecGCHours > 0 && UpdateSecGCMinutes > 0 && UpdateSecGCWithIntervalInHours > 0 && IsUpdateSecGCSchExecute == "Y")
                {
                    IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                    scheduler.Start();
                    IJobDetail job = JobBuilder.Create<UpdateSecondGCDataInBulk>().Build();
                    ITrigger trigger = TriggerBuilder.Create()
                        .WithDailyTimeIntervalSchedule
                          (s =>
                             s.WithIntervalInHours(UpdateSecGCWithIntervalInHours)
                            .OnEveryDay()
                            .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(UpdateSecGCHours, UpdateSecGCMinutes))
                          )
                        .Build();
                    scheduler.ScheduleJob(job, trigger);
                }

                // Generate Trips With New Parameters
                if (GenTripHours > 0 && GenTripMinutes > 0 && UpdateSecGCWithIntervalInHours > 0 && GenTripSchExecute == "Y")
                {
                    IScheduler scheduler = StdSchedulerFactory.GetDefaultScheduler();
                    scheduler.Start();
                    IJobDetail job = JobBuilder.Create<GenerateTripsWithParameters>().Build();
                    ITrigger trigger = TriggerBuilder.Create()
                        .WithDailyTimeIntervalSchedule
                          (s =>
                             s.WithIntervalInHours(GenTripWithIntervalInHours)
                            .OnEveryDay()
                            .StartingDailyAt(TimeOfDay.HourAndMinuteOfDay(GenTripHours, GenTripMinutes))
                          )
                        .Build();
                    scheduler.ScheduleJob(job, trigger);
                }


                BusinessCont.SaveLog(0, 100, 0, 0, 0, "SchedulerExecute - JobScheduler", "UpdateSecondGCDataInBulk - Hr= " + Hours + ", Min=" + Minutes + ", " +
                    "IsExecute= " + IsGenerateCordSchExecute + " || EmailSend -  Hr= " + HoursEmail + ", Min=" + MinutesEmail + ", IsExecute=" + IsEmailSchExecute + " || TripGeneration Hr= " + TripHours + "," +
                    " Min=" + TripMinutes + ", IsExecute=" + IsGenerateTripSchExecute + " || UpdateGCScheduler Hr= " + UpdateGCHours + ", Min=" + UpdateGCMinutes + ", IsExecute=" + IsUpdateGCSchExecute + " " +
                    "|| FindInsideOutsideConsumer Hr= " + HoursFindInsideOutside + ", Min=" + MinutesFindInsideOutside + ", IsExecute=" + IsFindInsideOutsideSchExecute + " || InsideOutsideConsumersScheduler Hr= " 
                    + InsideOutsideConsumersHours + ", Min=" + InsideOutsideConsumersMinutes + ", IsExecute=" + IsCheckInsideOutsideConsumersExecute, BusinessCont.SuccessStatus, null);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "SchedulerExecute - JobScheduler", "GenerateCoordinates - Hr= " + Hours + ", Min=" + Minutes + "," +
                    " IsExecute= " + IsGenerateCordSchExecute + " || EmailSend -  Hr= " + HoursEmail + ", Min=" + MinutesEmail + ", IsExecute=" + IsEmailSchExecute + "" +
                    " || TripGeneration Hr= " + TripHours + ", Min=" + TripMinutes + ", IsExecute=" + IsGenerateTripSchExecute + " || UpdateGCScheduler Hr= " +
                    UpdateGCHours + ", Min=" + UpdateGCMinutes + ", IsExecute=" + IsUpdateGCSchExecute + " || FindInsideOutsideConsumer Hr= " + HoursFindInsideOutside + ", " +
                    "Min=" + MinutesFindInsideOutside + ", IsExecute=" + IsFindInsideOutsideSchExecute + ", IsExecute=" + IsCheckInsideOutsideConsumersExecute + " || InsideOutsideConsumersScheduler Hr= " +
                    "" + InsideOutsideConsumersHours + ", Min=" + InsideOutsideConsumersMinutes + ", IsExecute=" + IsCheckInsideOutsideConsumersExecute, BusinessCont.FailStatus, ex.Message);
            }
        }

        public static void DeleteJob()
        {
            try
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "DeleteCurrentSchedulerJobExecute - Scheduler", "Start", "", null);
                var scheduler = StdSchedulerFactory.GetDefaultScheduler();
                scheduler.Clear();
                scheduler.Shutdown();
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "DeleteCurrentSchedulerJobExecute - Scheduler", "End", BusinessCont.SuccessStatus, null);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "DeleteCurrentSchedulerJobExecute - JobScheduler","", BusinessCont.FailStatus, ex.Message);
            }
        }

    }
}