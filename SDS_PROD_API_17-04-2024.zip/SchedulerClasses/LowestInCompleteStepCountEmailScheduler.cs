﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Aadyam.SDS.API.Controllers;
using Aadyam.SDS.Business.BusinessConstant;
using Quartz;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class LowestInCompleteStepCountEmailScheduler : BaseApiController, IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            int result1 = 0;
            try
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "LowestInCompleteStepCountEmailScheduler", "Lowest InComplete Step Count Scheduler Execution Start", BusinessCont.SuccessStatus, null);
                //result1 = _unitOfWork.geoCoordinateRepository.ExecuteEmailScheduler();
                result1 = _unitOfWork.geoCoordinateRepository.ExecuteLowestInCompleteStepCountEmailScheduler();
                
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "LowestInCompleteStepCountEmailScheduler", "Lowest InComplete Step Count Scheduler Execution End", BusinessCont.SuccessStatus, null);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, 0, 0, 0, "LowestInCompleteStepCountEmailScheduler", null, BusinessCont.FailStatus, ex.Message);
            }         
            try
            {
                if (result1 != 0)
                {
                    int result = _unitOfWork.geoCoordinateRepository.SaveEmailSchSendDate();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, 0, 0, 0, "Save Email scheduler Date", null, BusinessCont.FailStatus, ex.Message);
                throw ex;

            }
        }
    }
}