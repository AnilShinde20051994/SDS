﻿using Aadyam.SDS.API.Controllers;
using Aadyam.SDS.Business.BusinessConstant;
using Quartz;
using System;

namespace Aadyam.SDS.API.SchedulerClasses
{

    public class OnboardingEmailScheduler : BaseApiController, IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            int result1 = 0;
            try
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "OnboardingEmailScheduler", "Scheduler Execution Start", BusinessCont.SuccessStatus, null);
                result1 = _unitOfWork.geoCoordinateRepository.ExecuteEmailScheduler();
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "OnboardingEmailScheduler", "Scheduler Execution End", BusinessCont.SuccessStatus, null);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, 0, 0, 0, "OnboardingEmailScheduler", null, BusinessCont.FailStatus, ex.Message);
            }

            try
            {
                if (result1 != 0)
                {
                    int result = _unitOfWork.geoCoordinateRepository.SaveEmailSchSendDate();
                }
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, 0, 0, 0, "Save Email scheduler Date", null, BusinessCont.FailStatus, ex.Message);
            }
        }
    }
}