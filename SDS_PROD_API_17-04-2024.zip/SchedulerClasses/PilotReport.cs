﻿using Aadyam.SDS.API.Controllers;
using Aadyam.SDS.Business.BusinessConstant;
using Aadyam.SDS.Business.Model.Stock;
using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class PilotReport : BaseApiController, IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            List<DeliveryBoyList> DeliveryBoyDetails = new List<DeliveryBoyList>();
            int retValue = 0;
            try
            {
                BusinessCont.SaveLog(0, retValue, 0, 0, 0, "Pilot Report - Kilometer Save", "Scheduler", "START", "");

                DeliveryBoyDetails = _unitOfWork._tripRepository.getAllDeliveryBoyList(0);
                for (int i = 0; i < DeliveryBoyDetails.Count(); i++)
                {
                    retValue = _unitOfWork._tripRepository.getAllClusterTripKMSummary(DeliveryBoyDetails[i].DistributorId, Convert.ToString(DateTime.Now), Convert.ToString(DeliveryBoyDetails[i].DelBoyId));
                }

                BusinessCont.SaveLog(0, retValue, 0, 0, 0, "Pilot Report - Kilometer Save", "Scheduler", "END", "");
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, retValue, 0, 0, 0, "Pilot Report - Kilometer Save", "Scheduler", BusinessCont.FailStatus, ex.Message);
            }
        }

    }
}
            
    
