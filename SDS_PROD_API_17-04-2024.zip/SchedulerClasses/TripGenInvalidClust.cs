﻿using Aadyam.SDS.API.Controllers;
using Aadyam.SDS.Business.BusinessConstant;
using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class TripGenInvalidClust : BaseApiController, IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            bool result = false;
            try
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "TripGenInvalidReport", "Scheduler Execution Start", BusinessCont.SuccessStatus, null);
                result = _unitOfWork._tripRepository.GetInvalidClusterRpt();
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "TripGenInvalidReport", "Scheduler Execution End", BusinessCont.SuccessStatus, null);

            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, 0, 0, 0, "TripGenInvalidReport", null, BusinessCont.FailStatus, ex.Message);
            }
        }
    }
}