﻿using Aadyam.SDS.API.Controllers;
using Aadyam.SDS.Business.BusinessConstant;
using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class TripGenerationReport : BaseApiController, IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            bool result = false;
            try
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "TripGenerationReport", "Scheduler Execution Start", BusinessCont.SuccessStatus, null);
                result = _unitOfWork._tripRepository.GetTripGeneratioRpt();
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "TripGenerationReport", "Scheduler Execution End", BusinessCont.SuccessStatus, null);

            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 0, 0, 0, 0, "TripGenerationReport", null, BusinessCont.FailStatus, ex.Message);
            }
        }
    }
}