﻿using Aadyam.SDS.API.Controllers;
using Aadyam.SDS.Business.BusinessConstant;
using Quartz;
using System;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class TripPlanning: BaseApiController, IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            try
            {
                BusinessCont.SaveTripAuditLog(0, 100, 0, 0, 0, "TripPlanning - Scheduler", "Trip Generation Start", BusinessCont.SuccessStatus, null);
                _unitOfWork._tripRepository.SchedulerTripPlanning();
                BusinessCont.SaveTripAuditLog(0, 100, 0, 0, 0, "TripPlanning - Scheduler", "Trip Generation End", BusinessCont.SuccessStatus, null);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveTripAuditLog(0, 100, 0, 0, 0, "TripPlanning - Scheduler", null, BusinessCont.FailStatus, ex.Message);
            }
        }
    }

}