﻿using Aadyam.SDS.API.Controllers;
using Aadyam.SDS.Business.BusinessConstant;
using Quartz;
using System;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class UpdateAddressLocationInCDCMS : BaseApiController, IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            long ResultId = 0;
            try
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "CL - Update pending Consumer Address Location In CDCMS - Scheduler", "Update CAL Start", "", null);
                ResultId = _unitOfWork._LocationRepository.UpdateOnServerConsAddressLoc();
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "CL - Update pending Consumer Address Location In CDCMS - Scheduler", "Update CAL End " + "ResultId : " + ResultId, BusinessCont.SuccessStatus, null);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "CL - Update pending Consumer Address Location In CDCMS - Scheduler", null, BusinessCont.FailStatus, ex.Message);
            }
        }
    }
}