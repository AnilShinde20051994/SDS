﻿using Aadyam.SDS.API.Controllers;
using Aadyam.SDS.Business.BusinessConstant;
using Quartz;
using System;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class UpdateGCScheduler : BaseApiController, IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            long ResultId = 0;
            try
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "Update Google Coordinates Form CDCMS - Scheduler", "Update GC Start","", null);
                ResultId = _unitOfWork.geoCoordinateRepository.GetGCWiseConsumer();
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "Update Google Coordinates Form CDCMS - Scheduler", "Update GC End  " + "ResultId : " + ResultId, BusinessCont.SuccessStatus, null);
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "Update Google Coordinates Form CDCMS  - Scheduler", null, BusinessCont.FailStatus, ex.Message);
            }
        }
    }

}