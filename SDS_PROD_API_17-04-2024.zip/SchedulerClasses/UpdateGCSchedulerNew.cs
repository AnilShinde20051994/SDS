﻿using Aadyam.SDS.API.Controllers;
using Aadyam.SDS.Business.BusinessConstant;
using Quartz;
using System;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class UpdateGCSchedulerNew : BaseApiController, IJob
    {
        public void Execute(IJobExecutionContext context)
        {
            long ResultId = 0;
            try
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "Update GC New - Scheduler", "GetGCWiseConsumer_New", "START", "");
                ResultId = _unitOfWork.geoCoordinateRepository.GetGCWiseConsumer_New(0);
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "Update GC New - Scheduler", "GetGCWiseConsumer_New - ResultId : " + ResultId, "END", "");
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "Update GC New - Scheduler", "GetGCWiseConsumer_New - ResultId : " + ResultId + " & Exception = " + (ex.Message), BusinessCont.FailStatus, ex.Message);
            }
        }
    }

}