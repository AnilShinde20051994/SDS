﻿using Aadyam.SDS.API.Controllers;
using Aadyam.SDS.Business.BusinessConstant;
using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Aadyam.SDS.API.SchedulerClasses
{
    public class UpdateSecondGCDataInBulk : BaseApiController, IJob
    {

        public void Execute(IJobExecutionContext context)
        {
            long ResultId = 0;
            try
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "Update Second GC Data In Bulk - Scheduler", "UpdateSecondGCDataInBulk", "START", "");
                ResultId = _unitOfWork.geoCoordinateRepository.UpdateSecGCDataInBulk(0);
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "Update Second GC Data In Bulk - Scheduler", "UpdateSecondGCDataInBulk - ResultId : " + ResultId, "END", "");
            }
            catch (Exception ex)
            {
                BusinessCont.SaveLog(0, 100, 0, 0, 0, "Update Second GC Data In Bulk - Scheduler", "UpdateSecondGCDataInBulk - ResultId : " + ResultId + " & Exception = " + (ex.Message), BusinessCont.FailStatus, ex.Message);
            }
        }
    }
}